﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMT17OOP.Classes
{
    public class Kapi
    {

        public int KapiSayisi;


        public Kapi(int kapiSayisi)
        {
            KapiSayisi = kapiSayisi;
        }

    }
}
