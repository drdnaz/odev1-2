﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CMT17OOP.Classes
{
    public class Kasa
    {

        public string KasaTipi { get; private set; }

        public Kasa(string kasaTipi)
        {
            KasaTipi = kasaTipi;
        }
        //nesne oluşturmak için yaptım.

    }
}
